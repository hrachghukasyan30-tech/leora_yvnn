// Փոխիր այս ցանկի անունները, գները և բաժինները՝ քո իրական ապրանքներին համապատասխան։
const products = [
  {id:1,name:"Դասական բաճկոն",category:"tops",description:"Մինիմալիստական ոճ",price:24900,emoji:"🧥"},
  {id:2,name:"Ամենօրյա վերնաշապիկ",category:"tops",description:"Հարմարավետ և ոճային",price:15900,emoji:"👕"},
  {id:3,name:"Ուղիղ կտրվածքի տաբատ",category:"bottoms",description:"Ժամանակակից ձևվածք",price:18900,emoji:"👖"},
  {id:4,name:"Քաղաքային կոշիկներ",category:"shoes",description:"Ամենօրյա հավաքածու",price:32900,emoji:"👟"},
  {id:5,name:"Տաք սվիտեր",category:"tops",description:"Նոր սեզոնի ընտրանի",price:21900,emoji:"🧶"},
  {id:6,name:"Դասական գոտի",category:"accessories",description:"Նուրբ դետալ",price:9900,emoji:"〰️"},
  {id:7,name:"Սպորտային տաբատ",category:"bottoms",description:"Ազատ շարժման համար",price:16900,emoji:"👖"},
  {id:8,name:"Ուսապարկ",category:"accessories",description:"Գործնական աքսեսուար",price:19900,emoji:"🎒"}
];
let cart = [];
const money = n => n.toLocaleString("hy-AM") + " ֏";
const productsEl = document.getElementById("products");
function renderProducts(filter="all"){
  productsEl.innerHTML = products.filter(p=>filter==="all"||p.category===filter).map(p=>`
    <article class="product">
      <div class="product-visual"><span>${p.emoji}</span></div>
      <div class="product-info"><h3>${p.name}</h3><p>${p.description}</p>
        <div class="product-bottom"><span class="price">${money(p.price)}</span><button class="add" data-add="${p.id}">Ավելացնել +</button></div>
      </div>
    </article>`).join("");
}
function renderCart(){
  document.getElementById("cart-count").textContent=cart.reduce((s,x)=>s+x.qty,0);
  document.getElementById("floating-count").textContent=cart.reduce((s,x)=>s+x.qty,0);
  document.getElementById("cart-items").innerHTML=cart.length?cart.map(x=>`
    <div class="cart-row"><span>${x.name} × ${x.qty}</span><strong>${money(x.price*x.qty)}</strong><button data-remove="${x.id}">Հեռացնել</button></div>`).join(""):'<p class="empty">Զամբյուղը դեռ դատարկ է։</p>';
  document.getElementById("cart-total").textContent=money(cart.reduce((s,x)=>s+x.price*x.qty,0));
}
productsEl.addEventListener("click",e=>{
  const id=Number(e.target.dataset.add); if(!id)return;
  const p=products.find(x=>x.id===id), existing=cart.find(x=>x.id===id);
  if(existing)existing.qty++;else cart.push({...p,qty:1}); renderCart();
});
document.getElementById("cart-items").addEventListener("click",e=>{
  const id=Number(e.target.dataset.remove); if(!id)return;
  cart=cart.filter(x=>x.id!==id);renderCart();
});
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));
  btn.classList.add("active");renderProducts(btn.dataset.filter);
}));
const drawer=document.getElementById("cart-drawer"),scrim=document.getElementById("scrim");
function toggleCart(open){drawer.classList.toggle("open",open);scrim.classList.toggle("show",open)}
document.getElementById("open-cart").onclick=()=>toggleCart(true);
document.getElementById("close-cart").onclick=()=>toggleCart(false);
scrim.onclick=()=>toggleCart(false);
document.getElementById("checkout").onclick=()=>{
  if(!cart.length){alert("Զամբյուղը դատարկ է։");return;}
  const lines=cart.map(x=>`${x.name} × ${x.qty} — ${money(x.price*x.qty)}`).join("\n");
  const total=money(cart.reduce((s,x)=>s+x.price*x.qty,0));
  const msg=`Բարև, ուզում եմ պատվիրել LÈORA YVN-ից։\n${lines}\nԸնդամենը՝ ${total}`;
  window.open("https://wa.me/37455875005?text="+encodeURIComponent(msg),"_blank");
};
document.getElementById("year").textContent=new Date().getFullYear();
renderProducts();renderCart();
